exports.name = 'message';
exports.run = (client, message) => {
    if (message.author.bot) return;

    }

